package com.example.hissss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class DoctorRegistration extends AppCompatActivity {

    private TextView fullName,email,phone,password,regButton,gender,age,dep,workhrs;
    FirebaseAuth mAuth;
    DatabaseReference userDatabaseRef;
    ProgressDialog loader;
    FirebaseDatabase database= FirebaseDatabase.getInstance();
    String currentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_registration);

        fullName = findViewById(R.id.fullName);
        email = findViewById(R.id.email);
        phone = findViewById(R.id.phone);
        password = findViewById(R.id.password);
        regButton = findViewById(R.id.regButton);
        gender = findViewById(R.id.gender);
        age = findViewById(R.id.age);
        workhrs = findViewById(R.id.workhrs);
        dep = findViewById(R.id.dep);


        loader = new ProgressDialog(this);
        mAuth = FirebaseAuth.getInstance();

        FirebaseUser user= mAuth.getInstance().getCurrentUser();
        userDatabaseRef= database.getReference().child("Doctors");

        regButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Email,Password etc are variables
                final String Email= email.getText().toString().trim();
                final String Password= password.getText().toString().trim();
                final String FullName= fullName.getText().toString().trim();
                final String Phone= phone.getText().toString().trim();
                final String Gender= gender.getText().toString().trim();
                final String Age= age.getText().toString().trim();
                final String Work= workhrs.getText().toString().trim();
                final String Dep= dep.getText().toString().trim();


                if (TextUtils.isEmpty(Email)){
                    email.setError("Email is required!");
                    return;
                }

                if (TextUtils.isEmpty(Password)){
                    password.setError("Password is required!");
                    return;

                }

                if (TextUtils.isEmpty(Work)){
                    workhrs.setError("Working hours is required!");
                    return;

                }

                if (TextUtils.isEmpty(Dep)){
                    dep.setError("Department is required!");
                    return;

                }

                if (TextUtils.isEmpty(FullName)){
                    fullName.setError("Name is required!");
                    return;

                }

                if (TextUtils.isEmpty(Phone)){
                    phone.setError("Phone number is required!");
                    return;

                }

                if (TextUtils.isEmpty(Gender)){
                    gender.setError("Gender is required!");
                    return;

                }

                if (TextUtils.isEmpty(Age)){
                    age.setError("Age is required!");
                    return;

                }

                else{
                    loader.setMessage("Registration in process....");
                    loader.setCanceledOnTouchOutside(false);
                    loader.show();

                    mAuth.createUserWithEmailAndPassword(Email,Password)
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if(!task.isSuccessful()){
                                        String error =task.getException().toString();
                                        Toast.makeText(DoctorRegistration.this,
                                                "Error occurred:" + error,Toast.LENGTH_SHORT).show();
                                    }

                                    else{
                                        String currentUserId = mAuth.getCurrentUser().getUid();
                                        userDatabaseRef= database.getReference().child("Doctors").child(currentUserId);
                                        //HashMap userInfo = new HashMap();
                                        HashMap userInfo = new HashMap();
                                        userInfo.put("Name",FullName);
                                        userInfo.put("Email",Email);
                                        userInfo.put("Age",Age);
                                        userInfo.put("Gender",Gender);
                                        userInfo.put("Phone",Phone);
                                        userInfo.put("Password",Password);
                                        userInfo.put("Department",Dep);
                                        userInfo.put("Working hours",Work);

                                        //userDatabaseRef.setValue(userInfo);

                                        //Firebase itself will show error if already registered email is trying to sign up


                                        /*String userId = mAuth.getCurrentUser().getUid();
                                        DocumentReference docRef= fStore.collection("Users").document(userID);
                                        Map<String, Object> user= new HashMap<>();
                                        user.put("Name",fullName);
                                        user.put("Email",email);
                                        user.put("Age",age);
                                        user.put("Gender",gender);
                                        user.put("Phone",phone);
                                        user.put("Type","Patient");

                                        DocumentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void unused) {
                                                Log.d("TAG","OnSuccess"+userID);
                                            }
                                        });*/

                                        userDatabaseRef.updateChildren(userInfo).addOnCompleteListener(new OnCompleteListener() {
                                            @Override
                                            public void onComplete(@NonNull Task task) {
                                                if (task.isSuccessful()){
                                                    Toast.makeText(DoctorRegistration.this, "Details set Successful", Toast.LENGTH_SHORT).show();

                                                }

                                                else{
                                                    Toast.makeText(DoctorRegistration.this, task.getException().toString(), Toast.LENGTH_SHORT).show();

                                                }

                                            }
                                        });

                                    }

                                }
                            });

                    finish();//takes user to screen 1
                    loader.dismiss();
                }

            }
        });
    }
}