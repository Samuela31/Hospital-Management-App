package com.example.hissss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.StorageReference;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;

public class DoctorPage extends AppCompatActivity {

    TextView userName,schedule,hist,noti,dt;
    FirebaseAuth mAuth;
    DatabaseReference userDatabaseRef;
    ProgressDialog loader;
    FirebaseDatabase database= FirebaseDatabase.getInstance();
    CircleImageView image;
    private String str,DName;

    Date date = new Date();
    SimpleDateFormat formatter;
    String strDate;

    StorageReference storageRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_page);

        // create the get Intent object
        Intent intent = getIntent();

        // receive the value by getStringExtra() method
        // and key must be same which is send by first
        // activity
        str = intent.getStringExtra("message_key3");
        //Toast.makeText(PatientPage.this, str, Toast.LENGTH_SHORT).show();

        formatter = new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss");
        strDate = formatter.format(date);

        userName= (TextView) findViewById(R.id.name);
        noti=findViewById(R.id.noti);
        hist=findViewById(R.id.hist);
        schedule=findViewById(R.id.schedule);
        dt= findViewById(R.id.date);
        dt.setText(strDate);

        loader = new ProgressDialog(this);
        mAuth = FirebaseAuth.getInstance();

        FirebaseUser user= mAuth.getInstance().getCurrentUser();
        userDatabaseRef= database.getReference().child("Doctors");

        userDatabaseRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (task.isSuccessful()) {
                    for (DataSnapshot ds : task.getResult().getChildren()) {
                        String dbemail = ds.child("Email").getValue(String.class);
                        String dpname = ds.child("Name").getValue(String.class);


                        if (dbemail.equals(str)) {
                            userName.setText("Dr."+dpname);
                            DName=userName.getText().toString().trim();
                        }
                    }
                }
            }
        });

        noti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent= new Intent( DoctorPage.this, DoctorNotification.class);
                intent.putExtra("message_key4", str);
                startActivity(intent);
            }
        });

        schedule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent= new Intent( DoctorPage.this, DoctorSchedule.class);
                intent.putExtra("message_key4", str);
                startActivity(intent);
            }
        });

        hist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent= new Intent( DoctorPage.this, UpdateHistory.class);
                intent.putExtra("message_key4", str);
                intent.putExtra("message_key4.1", DName);
                startActivity(intent);
            }
        });

        /*out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                finish();

            }
        });*/

    }
}