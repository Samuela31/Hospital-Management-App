package com.example.hissss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class DoctorSchedule extends AppCompatActivity {
    FirebaseAuth mAuth;
    DatabaseReference docRef;
    ProgressDialog loader;
    FirebaseDatabase database= FirebaseDatabase.getInstance();
    String Text,flag="False";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_schedule);

        // create the get Intent object
        Intent intent = getIntent();

        // receive the value by getStringExtra() method
        // and key must be same which is send by first
        // activity
        String str = intent.getStringExtra("message_key4");

        loader = new ProgressDialog(this);
        mAuth = FirebaseAuth.getInstance();

        FirebaseUser user= mAuth.getInstance().getCurrentUser();
        docRef= database.getReference().child("Doctor Schedule");

        docRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (task.isSuccessful()) {
                    for (DataSnapshot ds : task.getResult().getChildren()) {
                        String dbdate = ds.child("Date").getValue(String.class);
                        String dbname = ds.child("Doctor").getValue(String.class);
                        String dpname = ds.child("Patient").getValue(String.class);
                        String dpemail = ds.child("Email").getValue(String.class);
                        String status = ds.child("Status").getValue(String.class);
                        String time = ds.child("Time").getValue(String.class);

                        //Toast.makeText(DoctorNotification.this, dbdate+"\n"+dbname+"\n"+dpname+"\n"+status, Toast.LENGTH_SHORT).show();


                        if (dbname.equals(str) && status.equals("Accepted")) {
                            Text=dpname+"\n"+dpemail+"\n"+time+" , "+dbdate+"\n"+"\n";
                            LinearLayout buttonContainer = (LinearLayout) findViewById(R.id.textcontainer);
                            TextView text= new TextView(getApplicationContext());
                            text.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                            text.setTextSize(25);
                            text.setText(Text);
                            buttonContainer.addView(text);
                            flag="True";
                            //Toast.makeText(DoctorNotification.this, Text, Toast.LENGTH_SHORT).show();

                        }
                    }

                    if(flag.equals("False")){
                        Text="No booked appointments";
                        LinearLayout buttonContainer = (LinearLayout) findViewById(R.id.textcontainer);
                        TextView text= new TextView(getApplicationContext());
                        text.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                        text.setTextSize(25);
                        text.setTextColor(Color.rgb(255,255,255));
                        text.setText(Text);
                        buttonContainer.addView(text);
                    }
                }
            }
        });


    }
}