package com.example.hissss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PatientPage extends AppCompatActivity {
    TextView userName,book,history,upcoming,cancel,dt;
    String email;
    FirebaseAuth mAuth;
    DatabaseReference userDatabaseRef;
    ProgressDialog loader;
    FirebaseDatabase database= FirebaseDatabase.getInstance();
    String flag="False",name;

    Date date = new Date();
    SimpleDateFormat formatter;
    String strDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_page);

        // create the get Intent object
        Intent intent = getIntent();

        // receive the value by getStringExtra() method
        // and key must be same which is send by first
        // activity
        String str = intent.getStringExtra("message_key");
        //Toast.makeText(PatientPage.this, str, Toast.LENGTH_SHORT).show();

        //https://compiler.javatpoint.com/opr/test.jsp?filename=SimpleDateFormatExample2
        formatter = new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss");
        strDate = formatter.format(date);

        userName= (TextView) findViewById(R.id.name);
        //userName.setText(str); //str is email not name
        book= findViewById(R.id.book);
        upcoming= findViewById(R.id.upcoming);
        history= findViewById(R.id.history);
        cancel= findViewById(R.id.cancel);
        dt= findViewById(R.id.date);

        dt.setText(strDate);

        loader = new ProgressDialog(this);
        mAuth = FirebaseAuth.getInstance();

        FirebaseUser user= mAuth.getInstance().getCurrentUser();
        userDatabaseRef= database.getReference().child("All Users");

        userDatabaseRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (task.isSuccessful()) {
                    for (DataSnapshot ds : task.getResult().getChildren()) {
                        String dbemail = ds.child("Email").getValue(String.class);
                        String dpname = ds.child("Name").getValue(String.class);

                                /*Toast.makeText(PatientLogin.this, dbemail, Toast.LENGTH_SHORT).show();
                                Toast.makeText(PatientLogin.this, dbpassword, Toast.LENGTH_SHORT).show();
                                Toast.makeText(PatientLogin.this, Email, Toast.LENGTH_SHORT).show();
                                Toast.makeText(PatientLogin.this, Password, Toast.LENGTH_SHORT).show();*/


                        if (dbemail.equals(str)) {
                            userName.setText(dpname);
                            name=dpname;
                        }
                    }
                }
            }
        });

        book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent( PatientPage.this, DoctorList.class);
                intent.putExtra("message_key", str);
                intent.putExtra("message_key.1", name);
                startActivity(intent);
            }
        });

        upcoming.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent( PatientPage.this, PatientAppointments.class);
                intent.putExtra("message_key", str);
                startActivity(intent);
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent( PatientPage.this, PCancel.class);
                intent.putExtra("message_key", str);
                startActivity(intent);
            }
        });

        history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent( PatientPage.this, ViewHistory.class);
                intent.putExtra("message_key", str);
                startActivity(intent);
            }
        });

    }
}