package com.example.hissss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ViewHistory extends AppCompatActivity {
    DatabaseReference patRef;
    FirebaseDatabase database= FirebaseDatabase.getInstance();
    String Text,flag="False",flag1="False",flag2="False";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_history);


        Intent intent = getIntent();

        // receive the value by getStringExtra() method
        // and key must be same which is send by first
        // activity
        String str = intent.getStringExtra("message_key");


        patRef= database.getReference().child("Patient History");

        patRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (task.isSuccessful()) {
                    for (DataSnapshot ds : task.getResult().getChildren()) {
                        String dbname = ds.child("Doctor").getValue(String.class);
                        String dpemail = ds.child("Patient").getValue(String.class);
                        String date = ds.child("Date").getValue(String.class);
                        String diag = ds.child("Diagnosis").getValue(String.class);
                        String pres = ds.child("Prescription").getValue(String.class);
                        String sym = ds.child("Symptoms").getValue(String.class);

                        //Toast.makeText(DoctorNotification.this, dbdate+"\n"+dbname+"\n"+dpname+"\n"+status, Toast.LENGTH_SHORT).show();


                        if (dpemail.equals(str)) {
                            Text="Doctor: "+dbname+"\n"+date+"\n"+"Symptoms: "+sym+"\n"+"Diagnosis: "+diag+"\n"+"Prescription: "+pres+"\n"+"\n";
                            LinearLayout buttonContainer = (LinearLayout) findViewById(R.id.textcontainer);
                            TextView text= new TextView(getApplicationContext());
                            text.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                            text.setTextSize(25);
                            text.setText(Text);
                            buttonContainer.addView(text);
                            flag="True";
                            //Toast.makeText(DoctorNotification.this, Text, Toast.LENGTH_SHORT).show();

                        }
                    }

                    if(flag.equals("False")){
                        Text="No patient history yet"+"\n";
                        LinearLayout buttonContainer = (LinearLayout) findViewById(R.id.textcontainer);
                        TextView text= new TextView(getApplicationContext());
                        text.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                        text.setTextSize(25);
                        text.setTextColor(Color.rgb(255,255,255));
                        text.setText(Text);
                        buttonContainer.addView(text);
                    }
                }
            }
        });
    }
}