package com.example.hissss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class PCancel extends AppCompatActivity {

    TextView calender,reject,display,text;
    FirebaseAuth mAuth;
    DatabaseReference docRef,patRef;
    ProgressDialog loader;
    FirebaseDatabase database= FirebaseDatabase.getInstance();
    String Text,flag="False",Date,flag1="False";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pcancel);

        Intent intent = getIntent();
        String str = intent.getStringExtra("message_key");

        display=findViewById(R.id.display1);
        reject=findViewById(R.id.reject);
        text=findViewById(R.id.text1);
        calender=findViewById(R.id.calender1);

        loader = new ProgressDialog(this);
        mAuth = FirebaseAuth.getInstance();

        MaterialDatePicker materialDatePicker=MaterialDatePicker.Builder.datePicker().
                setTitleText("Select date").setSelection(MaterialDatePicker.todayInUtcMilliseconds()).build();

        calender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                materialDatePicker.show(getSupportFragmentManager(),"Tag_Picker");
                materialDatePicker.addOnPositiveButtonClickListener(new MaterialPickerOnPositiveButtonClickListener() {
                    @Override
                    public void onPositiveButtonClick(Object selection) {
                        text.setText(materialDatePicker.getHeaderText());
                        Date=materialDatePicker.getHeaderText();
                    }
                });
            }
        });

        Date= display.getText().toString().trim();

        patRef= database.getReference().child("Patient Appointments");

        patRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (task.isSuccessful()) {
                    for (DataSnapshot ds : task.getResult().getChildren()) {
                        String dbdate = ds.child("Date").getValue(String.class);
                        String dbname = ds.child("Doctor").getValue(String.class);
                        String dpemail = ds.child("Patient").getValue(String.class);
                        String docemail = ds.child("Email").getValue(String.class);
                        String status = ds.child("Status").getValue(String.class);


                        //basically appointmented accepted means string length of status is more
                        //compared to Cancelled, Pending, etc
                        if (dpemail.equals(str) && (status.equals("Pending") || status.length()>10)) {
                            Text=dbdate+"\n"+dbname+"\n"+docemail+"\n"+"Appointment: "+status+"\n"+"\n";
                            LinearLayout buttonContainer = (LinearLayout) findViewById(R.id.textcontainer);
                            TextView text= new TextView(getApplicationContext());
                            text.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                            text.setTextSize(25);
                            text.setText(Text);
                            buttonContainer.addView(text);
                            flag="True";

                        }
                    }

                    if(flag.equals("False")){
                        Text="No pending appointments";
                        LinearLayout buttonContainer = (LinearLayout) findViewById(R.id.textcontainer);
                        TextView text= new TextView(getApplicationContext());
                        text.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                        text.setTextSize(25);
                        text.setTextColor(Color.rgb(255,255,255));
                        text.setText(Text);
                        buttonContainer.addView(text);
                    }
                }
            }
        });

        reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String Email = display.getText().toString().trim();

                if (TextUtils.isEmpty(Email)) {
                    display.setError("Doctor email is required!");
                    return;
                }
                else if(flag.equals("True")){
                    loader.setMessage("Loading....");
                    loader.setCanceledOnTouchOutside(false);
                    loader.show();

                    //patRef= database.getReference().child("Patient Appointments");
                    patRef = database.getReference().child("Patient Appointments");

                    patRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DataSnapshot> task) {
                            if (task.isSuccessful()) {
                                for (DataSnapshot ds : task.getResult().getChildren()) {
                                    String pat = ds.child("Patient").getValue(String.class);
                                    String date = ds.child("Date").getValue(String.class);
                                    String demail = ds.child("Email").getValue(String.class);

                                    //Toast.makeText(PCancel.this, Email, Toast.LENGTH_SHORT).show();

                                    if(pat.equals(str) && Date.equals(date) && demail.equals(Email)){

                                        ds.getRef().removeValue().addOnSuccessListener(new OnSuccessListener() {
                                            @Override
                                            public void onSuccess(Object o) {
                                                Toast.makeText(PCancel.this, "Appointment cancelled", Toast.LENGTH_SHORT).show();
                                            }
                                        });

                                        flag1="True";
                                    }

                                }

                                if(flag1.equals("False")){
                                    Toast.makeText(PCancel.this, "Error", Toast.LENGTH_SHORT).show();

                                }
                            }

                        }
                    });

                    docRef= database.getReference().child("Doctor Schedule");

                    docRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DataSnapshot> task) {
                            if (task.isSuccessful()) {
                                for (DataSnapshot ds : task.getResult().getChildren()) {
                                    String patemail = ds.child("Email").getValue(String.class);
                                    String date = ds.child("Date").getValue(String.class);
                                    String demail = ds.child("Doctor").getValue(String.class);

                                    if (patemail.equals(str) && Date.equals(date) && demail.equals(Email)) {

                                        ds.getRef().removeValue().addOnSuccessListener(new OnSuccessListener() {
                                            @Override
                                            public void onSuccess(Object o) {
                                                Toast.makeText(PCancel.this, "Details set successfully", Toast.LENGTH_SHORT).show();
                                            }
                                        });

                                        flag1 = "True";
                                    }

                                }

                                if (flag1.equals("False")) {
                                    Toast.makeText(PCancel.this, "Error", Toast.LENGTH_SHORT).show();

                                }
                            }
                        }
                    });
                    //finish();
                    loader.dismiss();

                }
            }
        });


    }
}