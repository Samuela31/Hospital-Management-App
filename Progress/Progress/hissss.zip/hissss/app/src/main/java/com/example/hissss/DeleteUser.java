package com.example.hissss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class DeleteUser extends AppCompatActivity {
    TextView docpat,emai,del;
    FirebaseAuth mAuth;
    DatabaseReference docRef,patRef;
    ProgressDialog loader;
    FirebaseDatabase database= FirebaseDatabase.getInstance();
    String Text,flag="False",flag1="False",flag2="False",flag3="False";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_user);

        docpat=findViewById(R.id.docpat);
        emai=findViewById(R.id.emai);
        del=findViewById(R.id.del);

        loader = new ProgressDialog(this);
        mAuth = FirebaseAuth.getInstance();

        patRef= database.getReference().child("All Users");

        patRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (task.isSuccessful()) {
                    for (DataSnapshot ds : task.getResult().getChildren()) {
                        String name = ds.child("Name").getValue(String.class);
                        String email = ds.child("Email").getValue(String.class);
                        String type = ds.child("Type").getValue(String.class);

                            Text=name+"\n"+email+"\n"+type+"\n"+"\n";
                            LinearLayout buttonContainer = (LinearLayout) findViewById(R.id.textcontainer);
                            TextView text= new TextView(getApplicationContext());
                            text.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                            text.setTextSize(25);
                            text.setText(Text);
                            buttonContainer.addView(text);
                            flag="True";

                    }

                    if(flag.equals("False")){
                        Text="No registered users";
                        LinearLayout buttonContainer = (LinearLayout) findViewById(R.id.textcontainer);
                        TextView text= new TextView(getApplicationContext());
                        text.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                        text.setTextSize(25);
                        text.setTextColor(Color.rgb(255,255,255));
                        text.setText(Text);
                        buttonContainer.addView(text);
                    }
                }
            }
        });

        flag="False"; //resetting
        docRef= database.getReference().child("Doctors");

        docRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (task.isSuccessful()) {
                    for (DataSnapshot ds : task.getResult().getChildren()) {
                        String name = ds.child("Name").getValue(String.class);
                        String email = ds.child("Email").getValue(String.class);

                        Text=name+"\n"+email+"\n"+"Doctor"+"\n"+"\n";
                        LinearLayout buttonContainer = (LinearLayout) findViewById(R.id.textcontainer);
                        TextView text= new TextView(getApplicationContext());
                        text.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                        text.setTextSize(25);
                        text.setText(Text);
                        buttonContainer.addView(text);
                        flag="True";

                    }

                    if(flag.equals("False")){
                        Text="No registered doctors";
                        LinearLayout buttonContainer = (LinearLayout) findViewById(R.id.textcontainer);
                        TextView text= new TextView(getApplicationContext());
                        text.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                        text.setTextSize(25);
                        text.setTextColor(Color.rgb(255,255,255));
                        text.setText(Text);
                        buttonContainer.addView(text);
                    }
                }
            }
        });

        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String user = docpat.getText().toString().trim();
                final String Email = emai.getText().toString().trim();

                if (TextUtils.isEmpty(user)) {
                    docpat.setError("Type \"Doctor\" or \"Patient\" !");
                    return;
                }

                if (TextUtils.isEmpty(Email)) {
                    emai.setError("User email is required!");
                    return;
                }

                else {
                        if (user.equals("Patient")) {
                            loader.setMessage("Loading....");
                            loader.setCanceledOnTouchOutside(false);
                            loader.show();

                            //patRef= database.getReference().child("Patient Appointments");
                            patRef = database.getReference().child("All Users");

                            patRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DataSnapshot> task) {
                                    if (task.isSuccessful()) {
                                        for (DataSnapshot ds : task.getResult().getChildren()) {
                                            String demail = ds.child("Email").getValue(String.class);

                                            //Toast.makeText(PCancel.this, Email, Toast.LENGTH_SHORT).show();

                                            if(demail.equals(Email)){

                                                ds.getRef().removeValue().addOnSuccessListener(new OnSuccessListener() {
                                                    @Override
                                                    public void onSuccess(Object o) {
                                                        Toast.makeText(DeleteUser.this, "User deleted", Toast.LENGTH_SHORT).show();
                                                    }
                                                });

                                                flag1="True";
                                            }

                                        }

                                        if(flag1.equals("False")){
                                            Toast.makeText(DeleteUser.this, "Error in deleting user", Toast.LENGTH_SHORT).show();

                                        }
                                    }

                                }
                            });

                            loader.dismiss();

                        }

                        else if (user.equals("Doctor")) {
                            loader.setMessage("Loading....");
                            loader.setCanceledOnTouchOutside(false);
                            loader.show();

                            //patRef= database.getReference().child("Patient Appointments");
                            docRef = database.getReference().child("Doctors");

                            docRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DataSnapshot> task) {
                                    if (task.isSuccessful()) {
                                        for (DataSnapshot ds : task.getResult().getChildren()) {
                                            String demail = ds.child("Email").getValue(String.class);

                                            //Toast.makeText(PCancel.this, Email, Toast.LENGTH_SHORT).show();

                                            if(demail.equals(Email)){

                                                ds.getRef().removeValue().addOnSuccessListener(new OnSuccessListener() {
                                                    @Override
                                                    public void onSuccess(Object o) {
                                                        Toast.makeText(DeleteUser.this, "Doctor deleted", Toast.LENGTH_SHORT).show();
                                                    }
                                                });

                                                flag1="True";
                                            }

                                        }

                                        if(flag1.equals("False")){
                                            Toast.makeText(DeleteUser.this, "Error in deleting doctor", Toast.LENGTH_SHORT).show();

                                        }
                                    }

                                }
                            });

                            docRef = database.getReference().child("Doctor Schedule");

                            docRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DataSnapshot> task) {
                                    if (task.isSuccessful()) {
                                        for (DataSnapshot ds : task.getResult().getChildren()) {
                                            String demail = ds.child("Doctor").getValue(String.class);

                                            //Toast.makeText(PCancel.this, Email, Toast.LENGTH_SHORT).show();

                                            if(demail.equals(Email)){

                                                ds.getRef().removeValue().addOnSuccessListener(new OnSuccessListener() {
                                                    @Override
                                                    public void onSuccess(Object o) {
                                                        Toast.makeText(DeleteUser.this, "Doctor schedules cleared", Toast.LENGTH_SHORT).show();
                                                    }
                                                });

                                                flag2="True";
                                            }

                                        }

                                        if(flag2.equals("False")){
                                            Toast.makeText(DeleteUser.this, "Error in clearing doctor schedule", Toast.LENGTH_SHORT).show();

                                        }
                                    }

                                }
                            });

                            docRef = database.getReference().child("Patient Appointments");

                            docRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DataSnapshot> task) {
                                    if (task.isSuccessful()) {
                                        for (DataSnapshot ds : task.getResult().getChildren()) {
                                            String demail = ds.child("Email").getValue(String.class);

                                            //Toast.makeText(PCancel.this, Email, Toast.LENGTH_SHORT).show();

                                            if(demail.equals(Email)){

                                                ds.getRef().removeValue().addOnSuccessListener(new OnSuccessListener() {
                                                    @Override
                                                    public void onSuccess(Object o) {
                                                        Toast.makeText(DeleteUser.this, "Patient appointments cleared", Toast.LENGTH_SHORT).show();
                                                    }
                                                });

                                                flag3="True";
                                            }

                                        }

                                        if(flag3.equals("False")){
                                            Toast.makeText(DeleteUser.this, "Error in clearing patient appointments", Toast.LENGTH_SHORT).show();

                                        }
                                    }

                                }
                            });

                            loader.dismiss();

                        }

                        else {
                            Toast.makeText(DeleteUser.this, "Enter correct email/user", Toast.LENGTH_SHORT).show();
                        }
                }
            }
        });
    }
}