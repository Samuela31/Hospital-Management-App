package com.example.hissss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

import java.util.Calendar;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;
import android.widget.TimePicker;

public class DoctorNotification extends AppCompatActivity {
    private TimePicker timePicker1;
    private TextView time;
    private Calendar calendar;
    private String format = "";

    TextView accept,reject,display,save,tim;
    FirebaseAuth mAuth;
    DatabaseReference docRef,patRef;
    ProgressDialog loader;
    FirebaseDatabase database= FirebaseDatabase.getInstance();
    String Text,flag="False",date,flag1="False",ApTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_notification);

        // create the get Intent object
        Intent intent = getIntent();

        // receive the value by getStringExtra() method
        // and key must be same which is send by first
        // activity
        String str = intent.getStringExtra("message_key4");

        //Toast.makeText(DoctorNotification.this, str, Toast.LENGTH_SHORT).show();

        /*Button button = new Button(this);
        button.setBackgroundColor(Color.rgb(71,240,57));
        button.setText("Accept");
        buttonContainer.addView(button);

        Button button = new Button(this);
        button.setBackgroundColor(Color.rgb(71,240,57));
        button.setText("Accept");
        buttonContainer.addView(button);*/
        timePicker1 = (TimePicker) findViewById(R.id.timePicker1);
        time = (TextView) findViewById(R.id.textView1);
        calendar = Calendar.getInstance();

        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int min = calendar.get(Calendar.MINUTE);
        showTime(hour, min);

        accept=findViewById(R.id.accept);
        reject=findViewById(R.id.reject);
        display=findViewById(R.id.display);
        save=findViewById(R.id.set_button);
        tim=findViewById(R.id.textView1);

        loader = new ProgressDialog(this);
        mAuth = FirebaseAuth.getInstance();

        FirebaseUser user= mAuth.getInstance().getCurrentUser();
        docRef= database.getReference().child("Doctor Schedule");

        docRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (task.isSuccessful()) {
                    for (DataSnapshot ds : task.getResult().getChildren()) {
                        String dbdate = ds.child("Date").getValue(String.class);
                        String dbname = ds.child("Doctor").getValue(String.class);
                        String dpname = ds.child("Patient").getValue(String.class);
                        String dpemail = ds.child("Email").getValue(String.class);
                        String status = ds.child("Status").getValue(String.class);

                        //Toast.makeText(DoctorNotification.this, ds.getValue(String.class), Toast.LENGTH_SHORT).show();

                        //Toast.makeText(DoctorNotification.this, dbdate+"\n"+dbname+"\n"+dpname+"\n"+status, Toast.LENGTH_SHORT).show();


                        if (dbname.equals(str) && status.equals("Pending")) {
                            Text=dbdate+"\n"+dpname+"\n"+dpemail+"\n"+"\n";
                            LinearLayout buttonContainer = (LinearLayout) findViewById(R.id.textcontainer);
                            TextView text= new TextView(getApplicationContext());
                            text.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                            text.setTextSize(25);
                            text.setText(Text);
                            buttonContainer.addView(text);
                            flag="True";
                            date=dbdate;
                            //Toast.makeText(DoctorNotification.this, Text, Toast.LENGTH_SHORT).show();

                        }
                    }

                    if(flag.equals("False")){
                        Text="No pending appointments";
                        LinearLayout buttonContainer = (LinearLayout) findViewById(R.id.textcontainer);
                        TextView text= new TextView(getApplicationContext());
                        text.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                        text.setTextSize(25);
                        text.setTextColor(Color.rgb(255,255,255));
                        text.setText(Text);
                        buttonContainer.addView(text);
                    }
                }
            }
        });


        accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String Email = display.getText().toString().trim();

                if (TextUtils.isEmpty(Email)) {
                    display.setError("Patient email is required!");
                    return;
                }
                else if(flag.equals("True")){
                    loader.setMessage("Loading....");
                    loader.setCanceledOnTouchOutside(false);
                    loader.show();

                    ApTime= time.getText().toString().trim();

                    /*Intent intent= new Intent( DoctorNotification.this, DNoti.class);
                    intent.putExtra("message_key5", Email);
                    intent.putExtra("message_key6", date);
                    startActivity(intent);*/

                    //patRef= database.getReference().child("Patient Appointments");
                    patRef = database.getReference().child("Patient Appointments");

                    patRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DataSnapshot> task) {
                            if (task.isSuccessful()) {
                                for (DataSnapshot ds : task.getResult().getChildren()) {
                                    String pat = ds.child("Patient").getValue(String.class);
                                    String doc = ds.child("Email").getValue(String.class);

                                    if(pat.equals(Email) && doc.equals(str)){
                                        HashMap update= new HashMap();
                                        update.put("Status",ApTime+" , "+date);

                                        String currentUserId = ds.getKey();
                                        //Toast.makeText(DoctorNotification.this, currentUserId, Toast.LENGTH_SHORT).show();

                                        ds.getRef().updateChildren(update).addOnSuccessListener(new OnSuccessListener() {
                                            @Override
                                            public void onSuccess(Object o) {
                                                Toast.makeText(DoctorNotification.this, "Appointment accepted", Toast.LENGTH_SHORT).show();
                                            }
                                        });

                                        flag1="True";
                                    }

                                }

                                if(flag1.equals("False")){
                                    Toast.makeText(DoctorNotification.this, "Error", Toast.LENGTH_SHORT).show();

                                }
                            }

                        }
                    });

                    docRef= database.getReference().child("Doctor Schedule");

                    docRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DataSnapshot> task) {
                            if (task.isSuccessful()) {
                                for (DataSnapshot ds : task.getResult().getChildren()) {
                                    String patemail = ds.child("Email").getValue(String.class);
                                    String doc = ds.child("Doctor").getValue(String.class);

                                    if (patemail.equals(Email) && doc.equals(str)) {
                                        HashMap update = new HashMap();
                                        update.put("Status", "Accepted");
                                        update.put("Time", ApTime);

                                        ds.getRef().updateChildren(update).addOnSuccessListener(new OnSuccessListener() {
                                            @Override
                                            public void onSuccess(Object o) {
                                                Toast.makeText(DoctorNotification.this, "Details set successfully", Toast.LENGTH_SHORT).show();
                                            }
                                        });

                                        flag1 = "True";
                                    }

                                }

                                if (flag1.equals("False")) {
                                    Toast.makeText(DoctorNotification.this, "Error", Toast.LENGTH_SHORT).show();

                                }
                            }
                        }
                    });
                    //finish();
                    loader.dismiss();

                }
            }
        });

        reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String Email = display.getText().toString().trim();

                if (TextUtils.isEmpty(Email)) {
                    display.setError("Patient email is required!");
                    return;
                }
                else if(flag.equals("True")){
                    loader.setMessage("Loading....");
                    loader.setCanceledOnTouchOutside(false);
                    loader.show();

                    /*Intent intent= new Intent( DoctorNotification.this, DNoti.class);
                    intent.putExtra("message_key5", Email);
                    intent.putExtra("message_key6", date);
                    startActivity(intent);*/

                    //patRef= database.getReference().child("Patient Appointments");
                    patRef = database.getReference().child("Patient Appointments");

                    patRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DataSnapshot> task) {
                            if (task.isSuccessful()) {
                                for (DataSnapshot ds : task.getResult().getChildren()) {
                                    String pat = ds.child("Patient").getValue(String.class);
                                    String doc = ds.child("Email").getValue(String.class);

                                    if(pat.equals(Email) && doc.equals(str)){
                                        HashMap update= new HashMap();
                                        update.put("Status","Cancelled");

                                        ds.getRef().updateChildren(update).addOnSuccessListener(new OnSuccessListener() {
                                            @Override
                                            public void onSuccess(Object o) {
                                                Toast.makeText(DoctorNotification.this, "Appointment rejected", Toast.LENGTH_SHORT).show();
                                            }
                                        });

                                        flag1="True";
                                    }

                                }

                                if(flag1.equals("False")){
                                    Toast.makeText(DoctorNotification.this, "Error", Toast.LENGTH_SHORT).show();

                                }
                            }

                        }
                    });

                    docRef= database.getReference().child("Doctor Schedule");

                    docRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DataSnapshot> task) {
                            if (task.isSuccessful()) {
                                for (DataSnapshot ds : task.getResult().getChildren()) {
                                    String patemail = ds.child("Email").getValue(String.class);
                                    String doc = ds.child("Doctor").getValue(String.class);

                                    if (patemail.equals(Email) && doc.equals(str)) {
                                        HashMap update = new HashMap();
                                        update.put("Status", "Rejected");

                                        ds.getRef().updateChildren(update).addOnSuccessListener(new OnSuccessListener() {
                                            @Override
                                            public void onSuccess(Object o) {
                                                Toast.makeText(DoctorNotification.this, "Details set successfully", Toast.LENGTH_SHORT).show();
                                            }
                                        });

                                        flag1 = "True";
                                    }

                                }

                                if (flag1.equals("False")) {
                                    Toast.makeText(DoctorNotification.this, "Error", Toast.LENGTH_SHORT).show();

                                }
                            }
                        }
                    });
                    //finish();
                    loader.dismiss();

                }
            }
        });


    }

    public void setTime(View view) {
        int hour = timePicker1.getCurrentHour();
        int min = timePicker1.getCurrentMinute();
        showTime(hour, min);
    }

    public void showTime(int hour, int min) {
        if (hour == 0) {
            hour += 12;
            format = "AM";
        } else if (hour == 12) {
            format = "PM";
        } else if (hour > 12) {
            hour -= 12;
            format = "PM";
        } else {
            format = "AM";
        }

        time.setText(new StringBuilder().append(hour).append(" : ").append(min)
                .append(" ").append(format));

    }
}