package com.example.hissss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class UpdateHistory extends AppCompatActivity {
    TextView update,prescription,diagnosis,symp,patemail,selectedDate;
    Button calenderButton;
    FirebaseAuth mAuth;
    DatabaseReference docRef,patRef,hisRef;
    ProgressDialog loader;
    FirebaseDatabase database= FirebaseDatabase.getInstance();
    String Text,Date,flag1="False",flag="False",flag2="False";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_history);

        // create the get Intent object
        Intent intent = getIntent();

        // receive the value by getStringExtra() method
        // and key must be same which is send by first
        // activity
        String str = intent.getStringExtra("message_key4");
        String DName = intent.getStringExtra("message_key4.1");

        update=findViewById(R.id.updatehist);
        prescription=findViewById(R.id.prescription);
        diagnosis=findViewById(R.id.diagnosis);
        symp=findViewById(R.id.symptom);
        patemail=findViewById(R.id.patient);
        selectedDate=findViewById(R.id.text1);
        calenderButton=findViewById(R.id.calender1);

        loader = new ProgressDialog(this);

        MaterialDatePicker materialDatePicker=MaterialDatePicker.Builder.datePicker().
                setTitleText("Select date").setSelection(MaterialDatePicker.todayInUtcMilliseconds()).build();

        calenderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                materialDatePicker.show(getSupportFragmentManager(),"Tag_Picker");
                materialDatePicker.addOnPositiveButtonClickListener(new MaterialPickerOnPositiveButtonClickListener() {
                    @Override
                    public void onPositiveButtonClick(Object selection) {
                        selectedDate.setText(materialDatePicker.getHeaderText());
                        Date=materialDatePicker.getHeaderText();
                    }
                });
            }
        });

        docRef= database.getReference().child("Doctor Schedule");

        docRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (task.isSuccessful()) {
                    for (DataSnapshot ds : task.getResult().getChildren()) {
                        String dbdate = ds.child("Date").getValue(String.class);
                        String dbname = ds.child("Doctor").getValue(String.class);
                        String dpemail = ds.child("Patient").getValue(String.class);
                        String docemail = ds.child("Email").getValue(String.class);
                        String status = ds.child("Status").getValue(String.class);


                        if (dbname.equals(str) && status.equals("Accepted")) {
                            Text=dbdate+"\n"+dpemail+"\n"+docemail+"\n"+"\n";
                            LinearLayout buttonContainer = (LinearLayout) findViewById(R.id.textcontainer);
                            TextView text= new TextView(getApplicationContext());
                            text.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                            text.setTextSize(25);
                            text.setText(Text);
                            buttonContainer.addView(text);
                            flag="True";

                        }
                    }

                    if(flag.equals("False")){
                        Text="No appointments";
                        LinearLayout buttonContainer = (LinearLayout) findViewById(R.id.textcontainer);
                        TextView text= new TextView(getApplicationContext());
                        text.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                        text.setTextSize(25);
                        text.setTextColor(Color.rgb(255,255,255));
                        text.setText(Text);
                        buttonContainer.addView(text);
                    }
                }
            }
        });


        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (Date != null) {
                    final String Pres = prescription.getText().toString().trim();
                    final String Diag = diagnosis.getText().toString().trim();
                    final String Sym = symp.getText().toString().trim();
                    final String Email = patemail.getText().toString().trim();

                    if (TextUtils.isEmpty(Pres)) {
                        prescription.setError("Prescription is required!");
                        return;
                    }

                    if (TextUtils.isEmpty(Email)) {
                        patemail.setError("Patient email is required!");
                        return;
                    }

                    if (TextUtils.isEmpty(Diag)) {
                        diagnosis.setError("Diagnosis is required!");
                        return;
                    }

                    if (TextUtils.isEmpty(Sym)) {
                        symp.setError("Symptoms is required!");
                        return;
                    }

                    else {
                        loader.setMessage("Loading....");
                        loader.setCanceledOnTouchOutside(false);
                        loader.show();

                        hisRef = database.getReference().child("Doctor Schedule");

                        hisRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DataSnapshot> task) {
                                if (task.isSuccessful()) {
                                    for (DataSnapshot ds : task.getResult().getChildren()) {
                                        String demail = ds.child("Doctor").getValue(String.class);
                                        String pemail = ds.child("Email").getValue(String.class);
                                        String status = ds.child("Status").getValue(String.class);
                                        String date = ds.child("Date").getValue(String.class);

                                        //Toast.makeText(PCancel.this, Email, Toast.LENGTH_SHORT).show();

                                        if (pemail.equals(Email) && date.equals(Date) && demail.equals(str) && status.equals("Accepted")) {

                                            ds.getRef().removeValue().addOnSuccessListener(new OnSuccessListener() {
                                                @Override
                                                public void onSuccess(Object o) {
                                                    Toast.makeText(UpdateHistory.this, "Doctor schedules cleared", Toast.LENGTH_SHORT).show();
                                                    hisRef = database.getReference().child("Patient History");
                                                    String currentUserId = hisRef.push().getKey();

                                                    hisRef = database.getReference().child("Patient History").child(currentUserId);
                                                    //HashMap userInfo = new HashMap();
                                                    HashMap userInfo = new HashMap();
                                                    userInfo.put("Date", Date);
                                                    userInfo.put("Patient", Email);
                                                    userInfo.put("Email", str);
                                                    userInfo.put("Doctor", DName);
                                                    userInfo.put("Symptoms", Sym);
                                                    userInfo.put("Diagnosis", Diag);
                                                    userInfo.put("Prescription", Pres);

                                                    hisRef.updateChildren(userInfo).addOnCompleteListener(new OnCompleteListener() {
                                                        @Override
                                                        public void onComplete(@NonNull Task task) {
                                                            if (task.isSuccessful()) {
                                                                Toast.makeText(UpdateHistory.this, "Patient history updated", Toast.LENGTH_SHORT).show();

                                                            } else {
                                                                Toast.makeText(UpdateHistory.this, task.getException().toString(), Toast.LENGTH_SHORT).show();

                                                            }

                                                        }

                                                    });

                                                    //patRef= database.getReference().child("Patient Appointments");
                                                    hisRef = database.getReference().child("Patient Appointments");

                                                    hisRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                                                        @Override
                                                        public void onComplete(@NonNull Task<DataSnapshot> task) {
                                                            if (task.isSuccessful()) {
                                                                for (DataSnapshot ds : task.getResult().getChildren()) {
                                                                    String demail = ds.child("Email").getValue(String.class);
                                                                    String pemail = ds.child("Patient").getValue(String.class);
                                                                    String date = ds.child("Date").getValue(String.class);

                                                                    //Toast.makeText(UpdateHistory.this, pemail+" "+Email, Toast.LENGTH_SHORT).show();
                                                                    //Toast.makeText(UpdateHistory.this, demail+" "+str, Toast.LENGTH_SHORT).show();
                                                                    //Toast.makeText(UpdateHistory.this, date+" "+Date, Toast.LENGTH_SHORT).show();

                                                                    if (pemail.equals(Email) && date.equals(Date) && demail.equals(str)) {

                                                                        ds.getRef().removeValue().addOnSuccessListener(new OnSuccessListener() {
                                                                            @Override
                                                                            public void onSuccess(Object o) {
                                                                                Toast.makeText(UpdateHistory.this, "Patient appointment cleared", Toast.LENGTH_SHORT).show();
                                                                            }
                                                                        });

                                                                        flag1 = "True";
                                                                    }

                                                                }

                                                                if (flag1.equals("False")) {
                                                                    Toast.makeText(UpdateHistory.this, "Error in clearing patient appointment", Toast.LENGTH_SHORT).show();

                                                                }
                                                            }

                                                        }
                                                    });

                                                }
                                            });

                                            flag2="True";
                                        }

                                    }

                                    if(flag2.equals("False")){
                                        Toast.makeText(UpdateHistory.this, "Error in clearing doctor schedule", Toast.LENGTH_SHORT).show();

                                    }
                                }

                            }
                        });

                        loader.dismiss();
                    }
                }

                else {
                    Toast.makeText(UpdateHistory.this, "Select date!", Toast.LENGTH_SHORT).show();

                }

            }

        });
    }
}