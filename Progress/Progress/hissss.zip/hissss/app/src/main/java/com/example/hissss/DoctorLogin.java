package com.example.hissss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class DoctorLogin extends AppCompatActivity {
    private TextView sign, email, password;
    FirebaseAuth mAuth;
    DatabaseReference userDatabaseRef;
    ProgressDialog loader;
    FirebaseDatabase database= FirebaseDatabase.getInstance();
    String flag="False";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_login);

        sign = findViewById(R.id.sign);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);

        loader = new ProgressDialog(this);
        mAuth = FirebaseAuth.getInstance();

        sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String Email= email.getText().toString().trim();
                final String Password= password.getText().toString().trim();

                if (TextUtils.isEmpty(Email)){
                    email.setError("Email is required!");
                    return;
                }

                if (TextUtils.isEmpty(Password)){
                    password.setError("Password is required!");
                    return;

                }

                else{
                    loader.setMessage("Loading....");
                    loader.setCanceledOnTouchOutside(false);
                    loader.show();

                    FirebaseUser user= mAuth.getInstance().getCurrentUser();
                    userDatabaseRef= database.getReference().child("Doctors");

                    userDatabaseRef.get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DataSnapshot> task) {
                            if (task.isSuccessful()) {
                                for (DataSnapshot ds : task.getResult().getChildren()) {
                                    String dbemail = ds.child("Email").getValue(String.class);
                                    String dbpassword = ds.child("Password").getValue(String.class);

                                /*Toast.makeText(PatientLogin.this, dbemail, Toast.LENGTH_SHORT).show();
                                Toast.makeText(PatientLogin.this, dbpassword, Toast.LENGTH_SHORT).show();
                                Toast.makeText(PatientLogin.this, Email, Toast.LENGTH_SHORT).show();
                                Toast.makeText(PatientLogin.this, Password, Toast.LENGTH_SHORT).show();*/


                                    if (dbemail.equals(Email) && dbpassword.equals(Password) ){
                                        Toast.makeText(DoctorLogin.this, "Sign in Successful!", Toast.LENGTH_SHORT).show();
                                        loader.dismiss();
                                        flag="True";
                                        Intent intent= new Intent( DoctorLogin.this, DoctorPage.class);

                                        // now by putExtra method put the value
                                        // in key, value pair key is message_key
                                        // by this key we will receive the
                                        // value, and put the string

                                        intent.putExtra("message_key3", Email);

                                        // start the Intent
                                        startActivity(intent);
                                    }
                                }

                                if(flag.equals("False")){
                                    Toast.makeText(DoctorLogin.this, "Wrong credentials!", Toast.LENGTH_SHORT).show();
                                    finish();
                                    loader.dismiss();
                                }
                            } else {
                                Log.d("TAG", task.getException().getMessage()); //Never ignore potential errors!
                            }
                        }
                    });


                }
            }
        });
    }
}