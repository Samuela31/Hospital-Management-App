package com.example.hissss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AdminPage extends AppCompatActivity {

    private TextView doctorRegis,patcnt,doccnt,freeroom,admitted,dt,delete;
    FirebaseAuth mAuth;
    DatabaseReference userRef,docRef;
    FirebaseDatabase database= FirebaseDatabase.getInstance();
    private int min=0,max=10;

    Date date = new Date();
    SimpleDateFormat formatter;
    String strDate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_page);

        formatter = new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss");
        strDate = formatter.format(date);

        doctorRegis = findViewById(R.id.doctorRegis);//inside bracket is id given to sign in button in activity_select_registration.xml
        patcnt = (TextView) findViewById(R.id.patcnt);
        doccnt = findViewById(R.id.doccnt);
        freeroom = findViewById(R.id.freeroom);
        admitted = findViewById(R.id.admitted);
        delete = findViewById(R.id.delete);
        dt= findViewById(R.id.date);

        dt.setText(strDate);

        userRef = database.getReference("All Users");

        userRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int counter = (int) snapshot.getChildrenCount();

                //Convert counter to string
                String userCounter = String.valueOf(counter);

                //Showing the user counter in the textview
                patcnt.setText("Registered users: "+userCounter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                patcnt.setText("TBA");
            }
        });

        docRef = database.getReference("Doctors");

        docRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int counter = (int) snapshot.getChildrenCount();

                //Convert counter to string
                String userCounter = String.valueOf(counter);

                //Showing the user counter in the textview
                doccnt.setText("Registered doctors: "+userCounter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                doccnt.setText("TBA");
            }
        });

        int b = (int)(Math.random()*(max-min+1)+min);
        String free = String.valueOf(b);
        freeroom.setText("Available rooms: "+free);

        int a=10-b;
        String admi=String.valueOf(a);
        admitted.setText("Admitted patients: "+admi);

        doctorRegis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent( AdminPage.this, DoctorRegistration.class);
                startActivity(intent);
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent( AdminPage.this, DeleteUser.class);
                startActivity(intent);
            }
        });


    }
}