package com.example.hissss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class DoctorList extends AppCompatActivity {


    TextView doc1,doc2,doc3,doc4;
    FirebaseAuth mAuth;
    DatabaseReference patUser;
    ProgressDialog loader;
    FirebaseDatabase database= FirebaseDatabase.getInstance();
    String Date;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_doctor_list);

            Intent intent = getIntent();

            // receive the value by getStringExtra() method
            // and key must be same which is send by first
            // activity
            String email = intent.getStringExtra("message_key");//patient email
            String name = intent.getStringExtra("message_key.1");//patient name

            doc1=findViewById(R.id.doc1);
            doc2=findViewById(R.id.doc2);
            doc3=findViewById(R.id.doc3);
            doc4=findViewById(R.id.doc4);

            loader = new ProgressDialog(this);
            mAuth = FirebaseAuth.getInstance();

            FirebaseUser user= mAuth.getInstance().getCurrentUser();
            //patUser= database.getReference().child("Patient Appointments");

            doc1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    loader.setMessage("Please wait....");
                    loader.setCanceledOnTouchOutside(false);
                    loader.show();

                    Intent intent= new Intent( DoctorList.this, Book.class);
                    intent.putExtra("message_key1", "elise@doc.com");
                    intent.putExtra("message_key2", email);
                    intent.putExtra("message_key2.1", name);
                    intent.putExtra("message_key2.2", "Dr.Elise Heather");
                    intent.putExtra("message_key2.3", "5925866");

                    startActivity(intent);


                    /*String currentUserId = mAuth.getCurrentUser().getUid();
                    patUser= database.getReference().child("Patient Appointments").child(currentUserId);
                                //HashMap userInfo = new HashMap();
                                HashMap userInfo = new HashMap();
                                userInfo.put("Date",Date);
                                userInfo.put("Patient",email);
                                userInfo.put("Doctor","Dr.Elise Heather");
                                userInfo.put("Phone","5925866");
                                userInfo.put("Status","Pending");

                                patUser.updateChildren(userInfo).addOnCompleteListener(new OnCompleteListener() {
                                    @Override
                                    public void onComplete(@NonNull Task task) {
                                        if (task.isSuccessful()){
                                            Toast.makeText(DoctorList.this, "Little more to go....", Toast.LENGTH_SHORT).show();

                                        }

                                        else{
                                            Toast.makeText(DoctorList.this, task.getException().toString(), Toast.LENGTH_SHORT).show();

                                        }

                                    }

                    });*/

                    loader.dismiss();
                    finish();

                    //Intent intent2= new Intent( DoctorList.this, PatientPage.class);
                    //startActivity(intent2);

                }

            });

            doc2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    loader.setMessage("Please wait....");
                    loader.setCanceledOnTouchOutside(false);
                    loader.show();

                    Intent intent= new Intent( DoctorList.this, Book.class);
                    intent.putExtra("message_key1", "brook@gm.com");
                    intent.putExtra("message_key2", email);
                    intent.putExtra("message_key2.1", name);
                    intent.putExtra("message_key2.2", "Dr.Brooklyn Masefield");
                    intent.putExtra("message_key2.3", "89659");
                    startActivity(intent);

                    // create the get Intent object
                   /* Intent intent1 = getIntent();

                    // receive the value by getStringExtra() method
                    // and key must be same which is send by first
                    // activity
                    Date = intent1.getStringExtra("message");
                    //Toast.makeText(PatientPage.this, str, Toast.LENGTH_SHORT).show();

                    String currentUserId = mAuth.getCurrentUser().getUid();
                    patUser= database.getReference().child("Patient Appointments").child(currentUserId);
                    //HashMap userInfo = new HashMap();
                    HashMap userInfo = new HashMap();
                    userInfo.put("Date",Date);
                    userInfo.put("Patient",email);
                    userInfo.put("Doctor","Dr.Brooklyn Masefield");
                    userInfo.put("Phone","89659");
                    userInfo.put("Status","Pending");

                    patUser.updateChildren(userInfo).addOnCompleteListener(new OnCompleteListener() {
                        @Override
                        public void onComplete(@NonNull Task task) {
                            if (task.isSuccessful()){
                                Toast.makeText(DoctorList.this, "Little more to go....", Toast.LENGTH_SHORT).show();

                            }

                            else{
                                Toast.makeText(DoctorList.this, task.getException().toString(), Toast.LENGTH_SHORT).show();

                            }

                        }

                    });*/

                    loader.dismiss();
                    finish();

                    //Intent intent2= new Intent( DoctorList.this, PatientPage.class);
                    //startActivity(intent2);

                }
            });

            doc3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    loader.setMessage("Please wait....");
                    loader.setCanceledOnTouchOutside(false);
                    loader.show();

                    Intent intent= new Intent( DoctorList.this, Book.class);
                    intent.putExtra("message_key1", "vani@gh.com");
                    intent.putExtra("message_key2", email);
                    intent.putExtra("message_key2.1", name);
                    intent.putExtra("message_key2.2", "Dr.Vanitha");
                    intent.putExtra("message_key2.3", "865865");
                    startActivity(intent);

                    // create the get Intent object
                    /*Intent intent1 = getIntent();

                    // receive the value by getStringExtra() method
                    // and key must be same which is send by first
                    // activity
                    Date = intent1.getStringExtra("message");
                    //Toast.makeText(PatientPage.this, str, Toast.LENGTH_SHORT).show();

                    String currentUserId = mAuth.getCurrentUser().getUid();
                    patUser= database.getReference().child("Patient Appointments").child(currentUserId);
                    //HashMap userInfo = new HashMap();
                    HashMap userInfo = new HashMap();
                    userInfo.put("Date",Date);
                    userInfo.put("Patient",email);
                    userInfo.put("Doctor","Dr.Vanitha");
                    userInfo.put("Phone","865865");
                    userInfo.put("Status","Pending");

                    patUser.updateChildren(userInfo).addOnCompleteListener(new OnCompleteListener() {
                        @Override
                        public void onComplete(@NonNull Task task) {
                            if (task.isSuccessful()){
                                Toast.makeText(DoctorList.this, "Little more to go....", Toast.LENGTH_SHORT).show();

                            }

                            else{
                                Toast.makeText(DoctorList.this, task.getException().toString(), Toast.LENGTH_SHORT).show();

                            }

                        }

                    });*/

                    loader.dismiss();
                    finish();

                    //Intent intent2= new Intent( DoctorList.this, PatientPage.class);
                    //startActivity(intent2);

                }
            });

            doc4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    loader.setMessage("Please wait....");
                    loader.setCanceledOnTouchOutside(false);
                    loader.show();

                    Intent intent= new Intent( DoctorList.this, Book.class);
                    intent.putExtra("message_key1", "austin@mu.in");
                    intent.putExtra("message_key2", email);
                    intent.putExtra("message_key2.1", name);
                    intent.putExtra("message_key2.2", "Dr.Austin R.P.");
                    intent.putExtra("message_key2.3", "56599");
                    startActivity(intent);

                    // create the get Intent object
                    /*Intent intent1 = getIntent();

                    // receive the value by getStringExtra() method
                    // and key must be same which is send by first
                    // activity
                    Date = intent1.getStringExtra("message");
                    //Toast.makeText(PatientPage.this, str, Toast.LENGTH_SHORT).show();

                    String currentUserId = mAuth.getCurrentUser().getUid();
                    patUser= database.getReference().child("Patient Appointments").child(currentUserId);
                    //HashMap userInfo = new HashMap();
                    HashMap userInfo = new HashMap();
                    userInfo.put("Date",Date);
                    userInfo.put("Patient",email);
                    userInfo.put("Doctor","Dr.Austin R.P.");
                    userInfo.put("Phone","56599");
                    userInfo.put("Status","Pending");

                    patUser.updateChildren(userInfo).addOnCompleteListener(new OnCompleteListener() {
                        @Override
                        public void onComplete(@NonNull Task task) {
                            if (task.isSuccessful()){
                                Toast.makeText(DoctorList.this, "Little more to go....", Toast.LENGTH_SHORT).show();

                            }

                            else{
                                Toast.makeText(DoctorList.this, task.getException().toString(), Toast.LENGTH_SHORT).show();

                            }

                        }

                    });*/

                    loader.dismiss();
                    finish();

                    //Intent intent2= new Intent( DoctorList.this, PatientPage.class);
                    //startActivity(intent2);

                }
            });

        }
    }

