package com.example.hissss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class Book extends AppCompatActivity {

    TextView selectedDate;
    Button calenderButton,ok;
    FirebaseAuth mAuth;
    DatabaseReference docUser, patRef;
    ProgressDialog loader;
    FirebaseDatabase database= FirebaseDatabase.getInstance();
    String Date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);

        Intent intent = getIntent();

        // receive the value by getStringExtra() method
        // and key must be same which is send by first
        // activity
        String docEmail = intent.getStringExtra("message_key1");
        String patEmail = intent.getStringExtra("message_key2");
        String patname = intent.getStringExtra("message_key2.1");
        String docname = intent.getStringExtra("message_key2.2");
        String dphone = intent.getStringExtra("message_key2.3");

        //Toast.makeText(Book.this, patname, Toast.LENGTH_SHORT).show();

        selectedDate=findViewById(R.id.text);
        calenderButton=findViewById(R.id.calender);
        ok=findViewById(R.id.ok);

        loader = new ProgressDialog(this);
        mAuth = FirebaseAuth.getInstance();

        FirebaseUser user= mAuth.getInstance().getCurrentUser();
        //docUser= database.getReference().child("Doctor Schedule");

        MaterialDatePicker materialDatePicker=MaterialDatePicker.Builder.datePicker().
                setTitleText("Select date").setSelection(MaterialDatePicker.todayInUtcMilliseconds()).build();

        calenderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                materialDatePicker.show(getSupportFragmentManager(),"Tag_Picker");
                materialDatePicker.addOnPositiveButtonClickListener(new MaterialPickerOnPositiveButtonClickListener() {
                    @Override
                    public void onPositiveButtonClick(Object selection) {
                        selectedDate.setText(materialDatePicker.getHeaderText());
                        Date=materialDatePicker.getHeaderText();
                    }
                });
            }
        });

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (Date != null) {

                    docUser = database.getReference().child("Doctor Schedule");
                    String currentUserId=docUser.push().getKey();

                    docUser = database.getReference().child("Doctor Schedule").child(currentUserId);
                    //HashMap userInfo = new HashMap();
                    HashMap userInfo = new HashMap();
                    userInfo.put("Date", Date);
                    userInfo.put("Patient", patname);
                    userInfo.put("Email", patEmail);
                    userInfo.put("Doctor", docEmail);
                    userInfo.put("Status", "Pending");

                    docUser.updateChildren(userInfo).addOnCompleteListener(new OnCompleteListener() {
                        @Override
                        public void onComplete(@NonNull Task task) {
                            if (task.isSuccessful()) {
                                String currentUserId = mAuth.getCurrentUser().getUid();

                                Toast.makeText(Book.this, "Appointment booked", Toast.LENGTH_SHORT).show();

                            } else {
                                Toast.makeText(Book.this, task.getException().toString(), Toast.LENGTH_SHORT).show();

                            }

                        }

                    });

                    patRef= database.getReference().child("Patient Appointments").child(currentUserId);
                    //HashMap userInfo = new HashMap();
                    HashMap patInfo = new HashMap();
                    patInfo.put("Date",Date);
                    patInfo.put("Patient",patEmail);
                    patInfo.put("Doctor",docname);
                    patInfo.put("Email",docEmail);
                    patInfo.put("Phone",dphone);
                    patInfo.put("Status","Pending");

                    patRef.updateChildren(patInfo).addOnCompleteListener(new OnCompleteListener() {
                        @Override
                        public void onComplete(@NonNull Task task) {
                            if (task.isSuccessful()){
                                Toast.makeText(Book.this, "Details set successfully", Toast.LENGTH_SHORT).show();

                            }

                            else{
                                Toast.makeText(Book.this, task.getException().toString(), Toast.LENGTH_SHORT).show();

                            }

                        }

                    });

                    // finish();

                }

                else {
                    Toast.makeText(Book.this, "Select date!", Toast.LENGTH_SHORT).show();

                }

                finish();

            }

        });

        }
}